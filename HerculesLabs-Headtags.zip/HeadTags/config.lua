Config = {
	Prefix = '^9[^1Hercules-Tags^9] ^3', -- Change My Name!
	TagsForStaffOnly = false, -- "DiscordTagIDs.Use.Tag-Toggle"
	roleList = {
		{ROLE-ID, "~w~Civilian"}, -- Change The Name
		{ROLE-ID, "~r~T-Mod ~w~"}, -- Change The Name 
		{ROLE-ID, "~r~Moderator ~w~"}, -- Change The Name
		{ROLE-ID, "~r~Admin ~w~"}, -- Change The Name
		{ROLE-ID, "~p~Management ~w~"}, -- Change The Name
		{ROLE-ID, "~o~Owner ~w~"}, -- Change The Name
	},
}