fx_version 'cerulean'
game 'gta5'

author 'HerculesLabs'
description 'Hercules\'s Headtags'

client_script 'config.lua'
client_script 'client.lua'
server_script "config.lua"
server_script "server.lua"

server_export "HideUserTag"
server_export "ShowUserTag"
